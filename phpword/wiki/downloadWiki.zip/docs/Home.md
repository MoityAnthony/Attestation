# Welcome to the homepage of PHPWord!

PHPWord is a library written in PHP that create word documents. 
No Windows operating system is needed for usage because the result are docx files (Office Open XML) that can be opened by all major office software.

PHPWord is based on the fantastic [PHPExcel](http://phpexcel.codeplex.com) / [PHPPowerPoint](http://phppowerpoint.codeplex.com) libraries.

## Major Features

* Insert and format document sections
* Insert and format Text elements
* Insert Text breaks
* Insert Page breaks
* Insert and format Images and binary OLE-Objects
* Insert and format watermarks (**new**)
* Insert Header / Footer
* Insert and format Tables
* Insert native Titles and Table-of-contents
* Insert and format List elements
* Insert and format hyperlinks
* Very simple template system (**new**)

See the [Documentation](http://phpword.codeplex.com/documentation) for all details.