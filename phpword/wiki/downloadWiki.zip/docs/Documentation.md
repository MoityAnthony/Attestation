# Requirements

* PHP 5.2.x or newer
* PHP Extension ZipArchive
* PHP Extension xmllib
* For opening by PHPWord created files in Microsoft Office < 2007 you need the "Microsoft Office Compatibility Pack". You can get it here for free: [Microsoft Office Compability Pack](http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=941b3470-3ae9-4aee-8f43-c6bb74cd1466)

# Installation and configuration

Installation and configuration is very easy:

* Extract the ZIP-Archive
* Copy the source files to your webserver
* If your PHPWord working directory isn't your PHP include path you can set the PHPWord base path. To set the PHPWord base path open the PHPWord.php inside the root folder and edit the value of {"PHPWORD_BASE_PATH"} constant.

# Basic example

{code:php}
// Include the PHPWord.php, all other classes were loaded by an autoloader
require_once 'PHPWord.php';

// Create a new PHPWord Object
$PHPWord = new PHPWord();

// Every element you want to append to the word document is placed in a section. So you need a section:
$section = $PHPWord->createSection();

// After creating a section, you can append elements:
$section->addText('Hello world!');

// You can directly style your text by giving the addText function an array:
$section->addText('Hello world! I am formatted.', array('name'=>'Tahoma', 'size'=>16, 'bold'=>true));

// If you often need the same style again you can create a user defined style to the word document
// and give the addText function the name of the style:
$PHPWord->addFontStyle('myOwnStyle', array('name'=>'Verdana', 'size'=>14, 'color'=>'1B2232'));
$section->addText('Hello world! I am formatted by a user defined style', 'myOwnStyle');

// You can also putthe appended element to local object an call functions like this:
$myTextElement = $section->addText('Hello World!');
$myTextElement->setBold();
$myTextElement->setName('Verdana');
$myTextElement->setSize(22);

// At least write the document to webspace:
$objWriter = PHPWord_IOFactory::createWriter($PHPWord, 'Word2007');
$objWriter->save('helloWorld.docx');
{code:php}

# Documentation
You can download examples and a full documentation of PHPWord [here](http://phpword.codeplex.com/releases/view/49543)

# Font Style changes between 0.6.1 and 0.6.2:
With the release 0.6.2 the paragraph properties has been moved into a separate Class!
So, every text element now has two style properties: FONT and PARAGRAPH. See the following example for more information:

{code:php}
// OLD release, 0.6.1:
$styleFont = array('bold'=>true, 'size'=>16, 'name'=>'Calibri', 'align'=>'center', 'spaceAfter'=>100);
$section->addText('Hello World', $styleFont);

// NEW release, 0.6.2:
$styleFont = array('bold'=>true, 'size'=>16, 'name'=>'Calibri');
$styleParagraph = array('align'=>'center', 'spaceAfter'=>100);
$section->addText('Hello World', $styleFont, $styleParagraph);
{code:php}